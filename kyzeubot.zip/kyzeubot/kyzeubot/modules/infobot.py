import asyncio
from pyrogram import Client, filters

# Informasi modul
__MODULE__ = "info bot"
__HELP__ = """
<b>Userbot Nexsora

⎆ adalah user bot NexSora yang digunakan untuk memudahkan pengguna dalam pekerjaan mereka seperti broadcast otomatis ke semua grup , convert gambar menjadi link , serta banyak lagi kegunaan nya
"""
