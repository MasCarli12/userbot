__MODULE__ = "ʙʟᴀᴄᴋʟɪꜱᴛ"
__HELP__ = """
<b>⦪ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ʙʟᴀᴄᴋ ʟɪsᴛ ⦫</b>

<blockquote><b>⎆ perintah :
ᚗ <code>{0}addbl</code>
⊷ memasukan group ke daftar blacklist

ᚗ <code>{0}unbl</code>
⊷ menghapus group dari daftar blacklist

ᚗ <code>{0}rallbl</code>
⊷ menghapus semua daftar blacklist group

ᚗ <code>{0}listbl</code>
⊷ memeriksa daftar blacklist group</b></blockquote>
"""
