module.exports = {
  tokens: "8775314737:AAFpvqnHUsdUZE0eRyvD5V3LeibLmtuho40",  // Masukin Bot token kamu
  owners: "5442592064", // Masukin ID Telegram kamu
  port: "443", // Masukin Port panel kamu 
  ipvps: "13.212.205.192" // Masukin IP vps kamu atau domain panel kamu yg asalnya ( https://AiiSigma.id ) menjadi ( http://AiiSigma.id )
};